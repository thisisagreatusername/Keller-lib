/*
 * Blue_Driver.h
 *
 * Created: 25.01.2016 17:02:50
 *  Author: tiws-16-12
 */ 


#ifndef BLUE_DRIVER_H_
#define BLUE_DRIVER_H_


#include <avr/io.h>
#include "Result.h"
void blue_init();
void blue_start();
RESULT blue_get(uint8_t* msg);
RESULT blue_send(uint8_t msg);
RESULT blue_sendbuff_free();
void blue_step();
#endif /* BLUE_DRIVER_H_ */