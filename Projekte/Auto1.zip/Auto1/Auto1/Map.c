/*
 * Map.c
 *
 * Created: 01.02.2016 22:27:20
 *  Author: tiws-16-10
 */ 
#include "Map.h"
#include "Result.h"
#include "Point.h"


#define multvorne 0.9346
#define multseite 0.00514


typedef Point Vector;
Point position = {0, 0};
Vector direction = {0, 1};




void update(double left, double right)
{
	if(left == 0 && right == 0)
		return;
	Vector v = pt_add(pt_scale(direction, multvorne*(left+right)), pt_scale(pt_CW90(direction), multseite*(right-left)));
	position = pt_add(position, v);
	direction = pt_norm(v);
}