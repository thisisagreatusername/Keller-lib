/*
 * Blue_Driver.c
 *
 * Created: 25.01.2016 17:02:59
 *  Author: tiws-16-12
 */ 
#include "Blue_Driver.h"
uint8_t send_msg;
uint8_t return_msg;
uint8_t byteGesendet;
uint8_t byteEmpfangen;

void blue_init()
{
	UCSR0C=0b110;                   // �bertragungsformat 8N1
	UBRR0=51;                       // 9600 Baud
	UCSR0B=(1<<RXEN0)|(1<<TXEN0);   // Empf�nger und Sender
}
RESULT blue_get(uint8_t* msg)
{
	if(!byteEmpfangen)
	return R_BUFF_NOT_READY;
	*msg = return_msg;
	byteEmpfangen = 0;
	return R_OK;
}

RESULT blue_send(uint8_t msg)
{
	if(!byteGesendet)
	return R_BUFF_NOT_READY;
	send_msg = msg;
	byteGesendet = 0;
	return R_OK;
}
RESULT blue_sendbuff_free()
{
	if((UCSR0A &(1<<UDRE0)) && (byteGesendet == 1))
		return R_OK;
	else
		return R_BUFF_NOT_READY;
}
void blue_step()
{
	if ((UCSR0A & (1<<RXC0)) && (byteEmpfangen == 0))		// wenn Byte empfangen
	{
		return_msg = UDR0;
		byteEmpfangen = 1;
	}
	if ((UCSR0A &(1<<UDRE0)) && (byteGesendet == 0))	// wenn Sendebuffer frei
	{
		UDR0 = send_msg;
		byteGesendet = 1;
	}
}