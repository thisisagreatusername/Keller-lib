/*
 * Map.h
 *
 * Created: 01.02.2016 22:27:05
 *  Author: tiws-16-10
 */ 


#ifndef MAP_H_
#define MAP_H_

#include <avr/io.h>


void update(double left, double right);


#endif /* MAP_H_ */