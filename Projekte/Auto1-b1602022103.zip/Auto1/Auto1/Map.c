/*
 * Map.c
 *
 * Created: 01.02.2016 22:27:20
 *  Author: tiws-16-10
 */ 
#include "Map.h"
#include "Result.h"
#include "Point.h"


#define multvorne 0.9346
#define multseite 0.00514


typedef Point Vector;
Point position = {0, 0};
Vector direction = {0, 1};


void Map_init()
{
	position.x = 0.0;
	position.y = 0.0;
	direction.x = 0.0;
	direction.y = 1.0;
}

void Map_update(float left, float right)
{
	//if(left == 0.0 && right == 0.0)
		//return;
	//position.y += right * multvorne;
	if(left != 0.0f)
	{
		const Vector v = pt_add(pt_scale(direction, multvorne), pt_scale(pt_CW90(direction), multseite));
		if(left < 0.0f)
		{
			Vector vn = pt_scale(v,-1.0f);
			position = pt_add(position, vn);
			direction = pt_norm(v);
		}
		else
		{
			position = pt_add(position, v);
			direction = pt_norm(v);
		}
	}
	if(right != 0.0f)
	{
		const Vector v = pt_add(pt_scale(direction, multvorne), pt_scale(pt_CW90(direction), multseite*(-1.0f)));
		if(right < 0.0f)
		{
			Vector vn = pt_scale(v,-1.0f);
			position = pt_add(position, vn);
			direction = pt_norm(v);
		}
		else
		{
			position = pt_add(position, v);
			direction = pt_norm(v);
		}
	}
	//Vector v = pt_add(pt_scale(direction, multvorne*(left+right)), pt_scale(pt_CW90(direction), multseite*(left-right)));
}

Point Map_getPos()
{
	return position;
}

PointI_16 Map_getSmallPos()
{
	static const int16_t divider = 20;
	
	PointI_16 res;
	res.x = (int16_t)(position.x + 0.5f);
	res.y = (int16_t)(position.y + 0.5f);
	res.x /= divider;
	res.y /= divider;
	return res;
}