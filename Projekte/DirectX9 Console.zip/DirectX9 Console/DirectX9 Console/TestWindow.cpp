#include "TestWindow.h"
#include "tools.h"
#include "3DCube.h"

void TestWindow::Start(LPDIRECT3DDEVICE9 pDevice)
{
	pMap = new Tilemap(pDevice,mapRes);
	pCarCube = new Cube3D(pDevice, D3DCOLOR_XRGB(255,0,0));

	carPos = PointF(mapRes / 2, mapRes / 2);

	carRot = PointF(10.0f,0.0f);
	carRotDes = carRot;
}

void TestWindow::DoFrame(LPDIRECT3DDEVICE9 pDevice, Camera& cam, float dt)
{
	if (!pMap)
		return;

	D3DXVECTOR3 vUp;

	if (viewMode)
	{
		if (carRot != carRotDes && !bMousing)
		{
			carRot = (carRot * 3.0f + carRotDes) / 4.0f;
		}
		camPos = D3DXVECTOR3(carRot.x + carPos.x, 10.0f, carRot.y + carPos.y);
		vUp = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	}
	else
	{
		camPos = D3DXVECTOR3(carPos.x, 20.0f, carPos.y);
		vUp = D3DXVECTOR3(1.0f, 0.0f, 0.0f);
		carRot = carRotDes;
	}


	cam.SetLookAt(camPos, D3DXVECTOR3(carPos.x, 0.0f, carPos.y), vUp);

	pDevice->SetTransform(D3DTS_VIEW, cam.GetLookAt());


	D3DXMATRIX matTrans;

	pMap->Draw(pDevice, nullptr, carPos);

	pMap->SetBlock(carPos, true);

	D3DXMatrixTranslation(&matTrans, carPos.x, 0.0f, carPos.y);
	
	pDevice->SetTransform(D3DTS_WORLD, &matTrans);
	pCarCube->Draw(pDevice);
}

LRESULT TestWindow::Message(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static POINT ptLastMousePosit;
	static POINT ptCurrentMousePosit;

	switch (msg)
	{
	case WM_LBUTTONDOWN:
	{
		ptLastMousePosit.x = ptCurrentMousePosit.x = LOWORD(lParam);
		ptLastMousePosit.y = ptCurrentMousePosit.y = HIWORD(lParam);
		bMousing = true;
	}
	break;

	case WM_LBUTTONUP:
	{
		bMousing = false;
	}
	break;

	case WM_KEYDOWN:
		switch (wParam)
		{
		case 'W':
			SetCar(carPos + PointF(1.0f,0.0f));
			break;
		case 'S':
			SetCar(carPos - PointF(1.0f, 0.0f));
			break;
		case 'A':
			SetCar(carPos + PointF(0.0f,1.0f));
			break;
		case 'D':
			SetCar(carPos - PointF(0.0f, 1.0f));
			break;
		case 'E':
			SetCar(carPos + PointF(1.0f, -1.0f));
			break;
		case 'Q':
			SetCar(carPos + PointF(1.0f, 1.0f));
			break;
		case VK_F1:
			viewMode = !viewMode;
			break;
		}
		break;

	case WM_MOUSEMOVE:
	{
		ptCurrentMousePosit.x = LOWORD(lParam);
		ptCurrentMousePosit.y = HIWORD(lParam);

		if (bMousing)
		{
			carRot = carRot.rot((ptCurrentMousePosit.x - ptLastMousePosit.x) * 0.01f);
		}

		ptLastMousePosit.x = ptCurrentMousePosit.x;
		ptLastMousePosit.y = ptCurrentMousePosit.y;
	}
	break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}

void TestWindow::End()
{
	SafeDelete(pMap);
	SafeDelete(pCarCube);
}