#pragma once
#include "Window.h"
#include "Tilemap.h"

class TestWindow : public Window
{
public:
	TestWindow()
		:
		Window()
	{}

	void SetWall(const PointI& p)
	{
		assert(pMap);
		pMap->SetBlock(p, true);
	}
	void SetCar(const PointF& c)
	{
		if (c != carPos)
		{
			carRotDes = (carPos - c).normalize() * 10.0f;
			carPos = c;
		}
	}
protected:
	virtual void Start(LPDIRECT3DDEVICE9) override;
	virtual void DoFrame(LPDIRECT3DDEVICE9, Camera& cam, float dt) override;
	virtual void End() override;
	virtual LRESULT Message(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) override;

private:
	Tilemap* pMap = nullptr;
	Cube3D* pCarCube = nullptr;
	const int mapRes = 500;
	D3DXVECTOR3 camPos;
	PointF carRot;
	PointF carRotDes;
	PointF carPos;
	PointF carVelo;
	bool viewMode = true;
	bool bMousing = false;;
};