#include "TestWindow.h"
#include "Input.h"
#include "Exception.h"
#include "Controller.h"
#include "Joystick.h"

#define SAVEFILE "config.dat"
int DefPortCar = 0;
int DefPortJoy = 0;

enum STATUS
{
	S_EXIT,
	S_INVALID,

	S_PORTTEST,
	S_PORTCONNECT,
	S_PORTCONJOY,
	S_MENU,
	S_JOYTEST,
	S_DXTEST
};

bool GetComHandle(HANDLE& h, int port);

STATUS MainLoop(Controller& car, Joystick* jst)
{
	STATUS r = S_INVALID;
	bool bChange = true;
	bool panic = false;

	//std::vector<char> data;

	while (!panic)
	{
		if (bChange && jst)
		{
			//redisplay
			Clear();
			printf("speed: %d\n", jst->GetSpeed());
			printf("direction: %d\n", jst->GetDir());

			/*if (data.size())
				printf("byte: %d\n",(unsigned int)(data.back() & 0x3f));*/
		}


		if (HasKey())
		{
			switch (GetKey())
			{
			case 'w':
				car.SetSpeed(1);
				break;
			case 's':
				car.SetSpeed(-1);
				break;
			case 'a':
				car.SetDirection(2);
				break;
			case 'd':
				car.SetDirection(-2);
				break;
			case 'r':
				car.SetSpeed(0);
				car.SetDirection(0);
				break;
			case 'q':
				panic = true;
				break;
			}
		}

		if (panic)
		{
			//panic was triggered by pc
			printf("force disconnect...\n");
			car.SendStop();
			printf("car disconnected..\n");
			if(jst) jst->SendDisconnect();
			printf("joystick disconnected..\n");
			break;
		}

		if (jst)
		{
			bChange = jst->Update();

			if (bChange)
			{
				assert(car.SetSpeed(jst->GetSpeed()));
				assert(car.SetDirection(jst->GetDir()));

				panic = jst->GetPanicButton();
				if (panic)
				{
					printf("joystick send panic! disconnect car...\n");
					car.SendStop();
					break;
				}
			}
		}
		//if (car.hasError())
		//{
		//	printf("Error in car\n");
		//	Pause();
		//}

		/*std::vector<char> inCar = car.GetData();
		if (inCar.size())
		{
			for (auto& c : inCar)
			{
				data.push_back((unsigned)c);
			}
			bChange = true;
		}*/
	}
	r = S_MENU;
	return r;
}

STATUS ConnectBlue(bool remoteJoystick)
{
	STATUS r = S_MENU;

	Joystick* pJst = NULL;
	HANDLE hj = NULL;
	//connect joystick
	if (remoteJoystick)
	{
		printf("connecting to joystick\n");
		if (!GetComHandle(hj, DefPortJoy))
		{
			return r;
		}

		pJst = new Joystick(hj);

		if (!pJst->Connected())
		{
			printf("\nconnection timed out\n");
			CloseHandle(hj);
			return r;
		}
		printf("\nconnection to joystick established!\n");
	}

	//connect car
	Sleep(1000);
	printf("connecting car...\n");
	HANDLE h;
	if (!GetComHandle(h,DefPortCar))
	{
		if (pJst)
			pJst->SendDisconnect();
		CloseHandle(hj);
		return r;
	}

	printf("connecting");
	Controller ctrl(h);

	if (!ctrl.Connected())
	{
		printf("\nconnection timed out\n");
		CloseHandle(h);
		if (pJst)
			pJst->SendDisconnect();
		CloseHandle(hj);
		return r;
	}
	printf("\nconnection to car established!\n");

	r = MainLoop(ctrl, pJst);

	CloseHandle(h);
	if (hj)
		CloseHandle(hj);
	delete pJst;
	pJst = NULL;

	printf("disconnected\n");
	return r;
}

void TestJoystick()
{
	STATUS r = S_MENU;
	HANDLE h;
	printf("connecting to joystick\n");
	if (!GetComHandle(h,DefPortJoy))
	{
		return;
	}

	Joystick joy(h);

	if (!joy.Connected())
	{
		printf("\nconnection timed out\n");
		CloseHandle(h);
		return;
	}
	printf("\nconnection to joystick established!\n");

	int k = 0;
	int direction = 0;
	int speed = 0;
	bool bChange = true;
	bool panic = true;

	while (k != 'q')
	{
		if (HasKey())
		{
			k = GetKey();
		}
		if (bChange)
		{
			Clear();
			printf("speed: %d\n", joy.GetSpeed());
			printf("direction: %d\n", joy.GetDir());
			if (joy.GetPanicButton())
			{
				printf("panic pressed!\n");
				panic = true;
				break;
			}
			bChange = false;
		}

		bChange = joy.Update();
	}

	printf("disconnecting...\n");
	if (!panic)
		joy.SendDisconnect();
	CloseHandle(h);
}

void DXTest()
{
	TestWindow tst;
	tst.Init(800, 600, L"DX9 test");

	while (tst.Update());
}

STATUS Menu();
void TestPorts();

int main()
{
	//load settings
	FILE* pFile = fopen(SAVEFILE, "rb");
	if (pFile)
	{
		fread(&DefPortCar, sizeof(int), 1, pFile);
		fread(&DefPortJoy, sizeof(int), 1, pFile);
		fclose(pFile);
	}
	else
	{
		printf("no save file found, please set default ports\n");
		printf("Car: ");
		DefPortCar = GetInt();
		printf("Joystick: ");
		DefPortJoy = GetInt();

		//save file
		pFile = fopen(SAVEFILE, "wb");
		fwrite(&DefPortCar, sizeof(int), 1, pFile);
		fwrite(&DefPortJoy, sizeof(int), 1, pFile);
		fclose(pFile);
	}

	STATUS r = S_MENU;

	while (r != S_EXIT)
	{
		Clear();
		switch (r)
		{
		case S_MENU:
			r = Menu();
			break;
		case S_PORTTEST:
			TestPorts();
			r = S_MENU;
			break;
		case S_PORTCONNECT:
			r = ConnectBlue(false);
			Pause();
			break;
		case S_PORTCONJOY:
			r = ConnectBlue(true);
			Pause();
			break;
		case S_JOYTEST:
			TestJoystick();
			r = S_MENU;
			Pause();
			break;
		case S_DXTEST:
			DXTest();
			r = S_MENU;
			break;
		default:
			printf("wrong state\n");
			Pause();
			return -1;
		}
	}
	return 0;
}

STATUS Menu()
{
	printf("Menu\n\n");
	printf("\t1. test ports\n");
	printf("\t2. connect to port without joystick\n");
	printf("\t3. connect to port\n");
	printf("\t4. test joystick\n");
	printf("\t5. test DX9\n");
	printf("\tq. quit\n");

	STATUS r = S_INVALID;

	while (r == S_INVALID)
	{
		switch (GetKey())
		{
		case '1':
			r = S_PORTTEST;
			break;
		case '2':
			r = S_PORTCONNECT;
			break;
		case '3':
			r = S_PORTCONJOY;
			break;
		case '4':
			r = S_JOYTEST;
			break;
		case '5':
			r = S_DXTEST;
			break;
		case 'q':
			r = S_EXIT;
			break;
		}
	}

	return r;
}
void TestPorts()
{
	printf("Testing Com Ports...\n");

	wchar_t buffer[20];

	for (int i = 0; i < 40; i++)
	{
		wsprintf(buffer, L"\\\\.\\COM%d", i);
		HANDLE h = ::CreateFile(buffer, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

		if (h != INVALID_HANDLE_VALUE)
		{
			wprintf(L"Port %s okay!\n", buffer);
			CloseHandle(h);
		}
	}

	Pause();
}
bool GetComHandle(HANDLE& h, int port)
{
	wchar_t buffer[20];
	wsprintf(buffer, L"\\\\.\\COM%d", port);
	wprintf(L"\nConnecting to %s\n", buffer);

	h = ::CreateFile(buffer, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 
		FILE_ATTRIBUTE_NORMAL, 0);
	if (h == INVALID_HANDLE_VALUE)
	{
		DWORD res = HRESULT_FROM_WIN32(GetLastError());
		exHRESULT e = exHRESULT("create file: ", res);
		wprintf(L"%s", buffer);
		printf("%s\n", e.what());
		return false;
	}
	printf("port found\n");

	printf("get device state...\n");

	DCB dcb;
	memset(&dcb, 0, sizeof(dcb));
	dcb.DCBlength = sizeof(dcb);
	if (GetCommState(h, &dcb) == 0)
	{
		printf("error getting device state\n");
		CloseHandle(h);
		return false;
	}
	printf("setting baud rate etc...\n");

	dcb.BaudRate = CBR_9600;
	dcb.ByteSize = 8;
	dcb.StopBits = ONESTOPBIT;
	dcb.Parity = NOPARITY;

	if (SetCommState(h, &dcb) == 0)
	{
		printf("error setting device parameters\n");
		CloseHandle(h);
		return false;
	}
	return true;
}
