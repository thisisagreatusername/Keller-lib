#pragma once
#include "ComHandle.h"
#include "cMutex.h"

class Controller :  public ComHandle
{
	class ComReader : public Thread
	{
	public:
		ComReader(HANDLE h)
			:
			h(h)
		{}
		virtual DWORD ThreadProc() override
		{
			while (1)
			{
				if (!IsRunning())
					return 0;

				char data;
				DWORD read;
				if (!ReadFile(h, &data, 1, &read, NULL))
				{
					if (GetLastError() == ERROR_IO_PENDING)
						printf("pending error whilst reading!\n");

					SetError();
					return -1;
				}

				muData.Lock();
				this->data.push_back(data);
				muData.Unlock();
			}
		}
		std::vector< char > GetData()
		{
			std::vector<char> res;
			
			muData.Lock();
			res = std::move(data);
			muData.Unlock();
			return res;
		}
	private:
		std::vector< char > data;
		cMutex muData;
		HANDLE h;
	};
public:
	Controller(HANDLE port)
		:
		ComHandle(port),
		isConnected(false)
		//reader(port)
	{
		//send init code
		if (!SendByte(MSG::CTRL_INIT))
		{
			printf("\n: could not send init code 0xC0\n");
			return;
		}
		printf("\ninit code 0xC0 sent\n");
		unsigned char tst = 0;
		for(int i = 0; i < 10; i++)
		{
			if (ReadByte(&tst))
			{
				if (tst == MSG::CTRL_INIT)
					break;

				printf("wrong response %X\n", tst);
				i--;
			}

			printf(".");
			Sleep(1000);
		}
		if (tst == MSG::CTRL_INIT)
		{
			isConnected = true;
			//reader.Begin();
		}
	}
	~Controller()
	{
		//reader.End();
	}
	bool Connected() const
	{
		return isConnected;
	}
	bool SetSpeed(char speed)
	{
		return SendByte(MSG::SPEED | to6Bit(speed));
	}
	// > 0 left  // < 0 right
	bool SetDirection(char dir)
	{
		return SendByte(MSG::STEER | to6Bit(dir));
	}
	void SendStop()
	{
		if (isConnected)
		{
			if (SendByte(MSG::SPECIAL | MSG::STOP))
			{
				isConnected = false;
			} 
		}
	}
	//std::vector< char > GetData()
	//{
	//	//std::vector< char > res;
	//	//unsigned char data;
	//	//if (ReadByte(&data))
	//	//{
	//	//	res.push_back(data);
	//	//}
	//	//return res;
	//	return reader.GetData();
	//}
	//bool hasError()
	//{
	//	return reader.HasError();
	//}
private:
	char speed;
	char dir;
	bool isConnected;
	//ComReader reader;
};