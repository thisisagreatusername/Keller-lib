/*
 * Map.c
 *
 * Created: 01.02.2016 22:27:20
 *  Author: tiws-16-10
 */ 
#include "Map.h"
#include "Result.h"
#include "Point.h"
#include "Led.h"

/*
#define multvorne 0.9346
#define multseite 0.00514
#define rotangle 0.005499623559444234f
#define rotangle2 (rotangle * 2.0f)
*/

typedef Point Vector;
Point position = {0, 0};
Vector direction = {0, 1};

//#define VX	0.0929370203f
//#define VY	0.000258603491f
//#define W 0.0929375f

#define VX	0.1858711623f / 2.0f
#define VY	0.001034406f / 2.0f
#define W 0.185875f

void Map_init()
{
	position.x = 0.0;
	position.y = 0.0;
	direction.x = 0.0;
	direction.y = 1.0;
}



void Map_update(float left, float right)
{
	Vector v;
	if(left == right)
	{
		if(left == 0.0f)
			return;
			
		if(left == 1.0f)
		{
			// both forward
			v = pt_scale(direction,W);
			position = pt_add(position,v);
		}
		else
		{
			// both backward
			v = pt_scale(direction,-W);
			position = pt_add(position,v);
		}
	}
	else
	{
		// left != right
		if( left * right == -1.0f)
		{
			// auf der stell
			if(right == 1.0f)
			{
				/*
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CCW90(direction),VY)); // y part
				//position = pt_add(position,v);
				direction = pt_norm(v);
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CCW90(direction),VY)); // y part
				direction = pt_norm(v);
				*/
				// right 1
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CCW90(direction),VY)); // y part
				//position = pt_add(position,v);
				direction = pt_norm(v);
				
				// left - 1 
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CCW90(direction),VY)); // y part
				
				direction = pt_norm(v);
				
				//v = pt_scale(v,-1.0f);
				//position = pt_add(position,v);
			}
			else
			{
				/*
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CW90(direction),VY)); // y part
				//position = pt_add(position,v);
				direction = pt_norm(v);
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CW90(direction),VY)); // y part
				//position = pt_add(position,v);
				direction = pt_norm(v);
				*/
				
				// right -1 
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CW90(direction),VY)); // y part
				
				direction = pt_norm(v);
				//v = pt_scale(v,-1.0f);
				//position = pt_add(position,v);
				
				// left +1
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CW90(direction),VY)); // y part
				//position = pt_add(position,v);
				direction = pt_norm(v);
			}
			
		}
		else if(left != 0.0f)
		{
			// left wheel
			if(left == 1.0f)
			{
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CW90(direction),VY)); // y part
				position = pt_add(position,v);
				direction = pt_norm(v);
			}
			else
			{
				// right forward
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CCW90(direction),VY)); // y part
				
				direction = pt_norm(v);
				
				v = pt_scale(v,-1.0f);
				position = pt_add(position,v);
			}
		}
		else
		{
			// right wheel
			if(right == 1.0f)
			{
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CCW90(direction),VY)); // y part
				position = pt_add(position,v);
				direction = pt_norm(v);
			}
			else
			{
				// left forward
				v = pt_add(
				pt_scale(direction,VX), // x part
				pt_scale(pt_CW90(direction),VY)); // y part
				
				direction = pt_norm(v);
				v = pt_scale(v,-1.0f);
				position = pt_add(position,v);
			}
		}
	}
	/*
	Vector v;

	switch((uint8_t)((left+1)*4 + (right+1)))
	{
		case 0b0000: // -1, -1
			v = pt_scale(direction, multvorne*(-2));
			position = pt_add(position, v);
			direction = pt_scale(pt_norm(v), -1.0f);
			break;
		case 0b0001: // -1, 0
			v = pt_add(pt_scale(direction, multvorne*(-1)), pt_scale(pt_CW90(direction), multseite*(-1)));
			position = pt_add(position, v);
			direction = pt_scale(pt_norm(v), -1.0f);
			break;
		case 0b0010: // -1, 1
			//v = pt_add(pt_scale(direction, multvorne*(1)), pt_scale(pt_CW90(direction), multseite*(-1)));
			//direction = pt_norm(v);
			//v = pt_add(pt_scale(direction, multvorne*(1)), pt_scale(pt_CW90(direction), multseite*(-1)));
			//direction = pt_norm(v);
			//direction = pt_norm(pt_rot(direction,rotangle2));
			//PORTJ++;
			break;
		case 0b0100: // 0, -1
			v = pt_add(pt_scale(direction, multvorne*(-1)), pt_scale(pt_CW90(direction), multseite*(1)));
			position = pt_add(position, v);
			direction = pt_scale(pt_norm(v), -1.0f);
			break;
		case 0b0101: // 0, 0
			break;
		case 0b0110: // 0, 1
			v = pt_add(pt_scale(direction, multvorne*(1)), pt_scale(pt_CW90(direction), multseite*(-1)));
			position = pt_add(position, v);
			direction = pt_norm(v);
			break;
		case 0b1000: // 1, -1
			//v = pt_add(pt_scale(direction, multvorne*(1)), pt_scale(pt_CW90(direction), multseite*(1)));
			//direction = pt_norm(v);
			//v = pt_add(pt_scale(direction, multvorne*(1)), pt_scale(pt_CW90(direction), multseite*(1)));
			//direction = pt_norm(v);
			//direction = pt_norm(pt_rot(direction,-rotangle2));
			//PORTJ++;
			break;
		case 0b1001: // 1, 0
			v = pt_add(pt_scale(direction, multvorne*(1)), pt_scale(pt_CW90(direction), multseite*(1)));
			position = pt_add(position, v);
			direction = pt_norm(v);
			break;
		case 0b1010: // 1, 1
			v = pt_scale(direction, multvorne*(2));
			position = pt_add(position, v);
			direction = pt_norm(v);
			break;
	}
	
	*/
	
	/*
	if(left == 0.0 && right == 0.0)
		return;
	//position.y += right * multvorne;
	if(left * right == -1.0f)	
	{
		if(left == -1.0f)
		{
			direction = pt_norm( RotCar( direction));	
			return;
		}
		else
		{
			direction = pt_norm( RotCarN( direction));	
			//const Vector v = pt_scale(pt_CW90(direction), -2.0f * multseite);
			//direction = pt_norm(v);
			return;
		}
	}
	
	if(left != 0.0f)
	{
		const Vector v = pt_add(pt_scale(direction, multvorne), pt_scale(pt_CW90(direction), multseite));
		if(left < 0.0f)
		{
			Vector vn = pt_scale(v,-1.0f);
			position = pt_add(position, vn);
			direction = pt_norm(v);
		}
		else
		{
			position = pt_add(position, v);
			direction = pt_norm(v);
		}
	}
	if(right != 0.0f)
	{
		const Vector v = pt_add(pt_scale(direction, multvorne), pt_scale(pt_CW90(direction), multseite*(-1.0f)));
		if(right < 0.0f)
		{
			Vector vn = pt_scale(v,-1.0f);
			position = pt_add(position, vn);
			direction = pt_norm(v);
		}
		else
		{
			position = pt_add(position, v);
			direction = pt_norm(v);
		}
	}
	//Vector v = pt_add(pt_scale(direction, multvorne*(left+right)), pt_scale(pt_CW90(direction), multseite*(left-right)));
	
	*/
}

Point Map_getPos()
{
	return position;
}

Point Map_getDir()
{
	return pt_norm(direction);
}

PointI_16 Map_getSmallPos()
{
	static const int16_t divider = 2;
	
	PointI_16 res;
	res.x = (int16_t)(position.x + 0.5f);
	res.y = (int16_t)(position.y + 0.5f);
	res.x /= divider;
	res.y /= divider;
	return res;
}